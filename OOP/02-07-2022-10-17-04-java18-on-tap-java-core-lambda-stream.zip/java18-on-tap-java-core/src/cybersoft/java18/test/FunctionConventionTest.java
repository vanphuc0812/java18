package cybersoft.java18.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import cybersoft.java18.javacore.FunctionConvention;

public class FunctionConventionTest {
	
	@Test
	void shouldCheckSoChanWorkCorrectly() {
		assertEquals(true, FunctionConvention.checkSoChan(2));
	}
	
	@Test
	void shouldCheckSoNguyenToWorkCorrectly() {
		assertEquals(false, FunctionConvention.checkSoNguyenTo(-5));
		assertEquals(false, FunctionConvention.checkSoNguyenTo(0));
		assertEquals(true, FunctionConvention.checkSoNguyenTo(3));
		assertEquals(true, FunctionConvention.checkSoNguyenTo(7));
		assertEquals(true, FunctionConvention.checkSoNguyenTo(23));
		assertEquals(false, FunctionConvention.checkSoNguyenTo(12));
		assertEquals(false, FunctionConvention.checkSoNguyenTo(21));
		assertEquals(false, FunctionConvention.checkSoNguyenTo(48));
	}
}
