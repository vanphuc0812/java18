package cybersoft.java18.javacore;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class CustomFileProcessor {
	/** execute-around pattern
	 * 
	 * Prepare/Init
	 * 
	 * processing
	 * 
	 * Cleanup/Close
	 */
	// behavior parameterization
	public String processFile(String path, 
			BufferedReaderProcessor processor) {
		try (BufferedReader br = 
				new BufferedReader(new FileReader(path))) { // init
			// processing
			return processor.process(br);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}
	
	@FunctionalInterface
	public interface BufferedReaderProcessor {
		
		// signature
		// function descriptor
		// (BufferedReader) -> String
		String process(BufferedReader br) throws IOException;
		
		default void sayHello() {
			System.out.println("Hello");
		}
	}
}
