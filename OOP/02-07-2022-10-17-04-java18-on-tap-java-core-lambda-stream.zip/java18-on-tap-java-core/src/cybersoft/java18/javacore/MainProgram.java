package cybersoft.java18.javacore;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import cybersoft.java18.javacore.CustomFileProcessor.BufferedReaderProcessor;

public class MainProgram {
	public static void main(String[] args) throws IOException {
		CustomFileProcessor fileProcessor =
				new CustomFileProcessor();
		String path =
				"/Users/user/Google Drive/Cybersoft/Lớp/Java18/java18-on-tap-java-core/src/data.csv";
		
		BufferedReaderProcessor 
			processor = new BufferedReaderProcessor() {
				
				public String process(BufferedReader br) throws IOException {
					return br.readLine() + br.readLine();
				}
			};
		
		String fileContent =
				fileProcessor.processFile(path, processor);
		
		System.out.println(fileContent);
		
		BufferedReaderProcessor 
			readOneLineProcessor = br -> br.readLine();
			
		BufferedReaderProcessor 
			functionRefProcessor = BufferedReader::readLine;
			
		List<Integer> listInt = new ArrayList<>();
		listInt.add(5); // 5 -> Integer(5) : Boxing
		// Unboxing
		int soInt = new Integer(50); // AutoBoxing
		
		fileContent = 
				fileProcessor.processFile(path, readOneLineProcessor);
		System.out.println("File Content: " + fileContent);
	}
}
