package cybersoft.java18.javacore;

import java.util.Scanner;

public class FunctionConvention {
	/**
	 * <access modifier> return-type tenFunction (parameterType params,...) {
	 * 		function body
	 * 		return 
	 * }
	 */
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		sayHello("Tuấn", "anh");
		System.out.print("Mời nhập một số nguyên: ");
		int soN = scanner.nextInt();
		
		if(checkSoChan(soN)) {
			System.out.printf("\n %d là số chẵn", soN);
		} else {
			System.out.printf("\n %d là số lẻ", soN);
		}
	}
	
	/***
	 * Chương trình in ra câu chào mừng trong màn hình console
	 * @param name Tên của bạn
	 * @param welcomeName cách xưng hô
	 */
	public static void sayHello(String name, String welcomeName) {
		System.out.printf("Welcome %s %s to Java course. %n", welcomeName, name);
	}
	
	public static boolean checkSoChan(int soN) {
		return soN % 2 == 0;
	}
	
	/***
	 * Hàm kiểm tra số nguyên tố
	 * @param soN số tự nhiên
	 * @return <true> nếu soN là số nguyên tố, <false> nếu soN không phải là số nguyên tố
	 */
	public static boolean checkSoNguyenTo(int soN) {
		if (soN <= 1) {
			return false;
		}
		
		for(int i = 2; i <= Math.sqrt(soN); i++) {
			if (soN % i == 0) {
				return false;
			}
		}
		
		return true;
	}
}
