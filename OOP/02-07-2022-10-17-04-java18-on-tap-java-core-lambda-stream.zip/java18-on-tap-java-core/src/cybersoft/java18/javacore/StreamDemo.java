package cybersoft.java18.javacore;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class StreamDemo {
	public static void main(String[] args) {
		// Collections
		List<Student> students = new ArrayList<>();
		students.add(new Student("SV01", "Micheal Cor", GENDER.MALE, 3.8f, new Address("Ho Chi Minh")));
		students.add(new Student("SV02", "Edward Snowden", GENDER.MALE, 2.5f, new Address("Da Nang")));
		students.add(new Student("SV03", "Emma Watson", GENDER.FEMALE, 3.7f, new Address("Ha Noi")));
		students.add(new Student("SV04", "Tom Cruise", GENDER.MALE, 4f, new Address("Can Tho")));
		students.add(new Student("SV05", "Amber Heart", GENDER.FEMALE, 1.8f, new Address("Yangoon")));
		students.add(new Student("SV06", "Johny Dep", GENDER.MALE, 2.8f, new Address("Bangkok")));
		students.add(new Student("SV07", "Nicole Eggimann", GENDER.FEMALE, 4f, new Address("Bangkok")));
		students.add(new Student("SV08", "Yannick Houser", GENDER.MALE, 1.5f, new Address("Da Nang")));
		students.add(new Student("SV09", "Winistofer Beat", GENDER.MALE, 2.6f, new Address("Ho Chi Minh")));
		
		List<Student> femaleStudents = new ArrayList<>();
		for(Student st : students) {
			if (st.gender == GENDER.FEMALE)
				femaleStudents.add(st);
		}
		
		System.out.println(femaleStudents);
		
		Predicate<Student> 
			femaleStudentPredicate = st -> st.gender == GENDER.FEMALE;
		
		femaleStudents = students.stream()
				.filter(femaleStudentPredicate)
				.collect(Collectors.toList());
		
		System.out.println("Female student: " + femaleStudents.toString());
		
		List<Student> graduatedStudents
			= students.parallelStream()
				.filter(st -> st.avgPoint >= 2f)
				.collect(Collectors.toList());
		System.out.println("Graduated students: " + graduatedStudents);
		
		List<String> maxPointStudents =
				students.stream()
					.filter(st -> st.avgPoint == 4f)
					.map(st -> st.name)
					.collect(Collectors.toList());
		System.out.println("Max point students: " + maxPointStudents);
		
		// check if all student have passed the test
		boolean allPassed = 
				students.stream()
					.allMatch(st -> st.avgPoint >= 2);
		System.out.println("All student passed the exam: " + allPassed);
		
		// check if any student has avg 4
		boolean hasMaxPointStudent =
				students.stream()
					.anyMatch(st -> st.avgPoint == 4f);
		System.out.println("Has max point student: " + hasMaxPointStudent);
		
		// get city list that student's living
		List<String> cities = 
				students.stream()
					.map(st -> st.address)
					.map(add -> add.city)
					.distinct()
					.collect(Collectors.toList());
		System.out.println("Cities: " + cities);
			
	}
	
	// inner class
	public static class Student {
		protected String code;
		protected String name;
		protected GENDER gender;
		protected float avgPoint;
		protected Address address;
		
		protected Student(String code, String name,
				GENDER gender, float avgPoint, Address address) {
			this.code = code;
			this.name = name;
			this.gender = gender;
			this.avgPoint = avgPoint;
			this.address = address;
		}
		
		@Override
		public String toString() {
			return this.name;
		}
	}
	
	public static class Address {
		protected String city;
		protected String district;
		protected String ward;
		protected String street;
		protected String number;
		
		public Address(String city) {
			this.city = city;
		}
	}
	
	public static enum GENDER {
		MALE,
		FEMALE
	}
}
