package cybersoft.java18.javacore;

public class NamingConvention {
	public static void main(String[] args) {
		System.out.println("ThisIsPascalCase");
		System.out.println("thisIsCamelCase");
		System.out.println("camelCase");
		System.out.println("PascalCase");
		
		System.out.println("Tên lớp -> PascalCase");
		System.out.println("Tên biến, tên hàm, tham số -> camelCase");
	}
}
