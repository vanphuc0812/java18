package cybersoft.java18.javacore;

import java.util.function.Predicate;

public class DataType {
	/*
	 * Primitive
	 */
	public void primitiveDataType () {
		// number and logic
		
		// số nguyên
		// byte
		// int
		// long
		// char
		
		// số thực
		// float
		// double
		
		// logic
		// boolean
		
		// reference
		// Object: ArrayList, SinhVien, BankAccount
		// String
		
		Predicate<String> specialString = str -> str.length() > 1000;
	}
}
