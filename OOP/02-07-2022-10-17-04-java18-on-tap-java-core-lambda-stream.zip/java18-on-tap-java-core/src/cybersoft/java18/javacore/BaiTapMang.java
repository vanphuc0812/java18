package cybersoft.java18.javacore;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

public class BaiTapMang {
	void demoMang() {
		int[] mangInt = new int[3];
		mangInt[0] = 15;
		List<Integer> listInt;
		listInt = new ArrayList<>();
		listInt = new LinkedList<>();
	}
	
	/***
	 * Hàm trả về danh sách các số nguyên tố có trong mảng
	 * @param mangInt mảng các số nguyên
	 * @return danh sách chưa các số nguyên tố
	 */
	public static List<Integer> layDsSoNguyenToTuMang(final List<Integer> mangInt) {
		// List<Integer> results = new LinkedList<>();
		
		/*
		for(int soN : mangInt) {
			if (FunctionConvention.checkSoNguyenTo(soN))
				results.add(soN);
		} 
		
		mangInt.stream().forEach(soN -> {
			if (FunctionConvention.checkSoNguyenTo(soN))
				results.add(soN);
		}); */
		
		List<Integer> results = mangInt.stream()
			.filter(soN -> FunctionConvention.checkSoNguyenTo(soN))
			.collect(Collectors.toList());
		
		return results;
	}
	
	
}
