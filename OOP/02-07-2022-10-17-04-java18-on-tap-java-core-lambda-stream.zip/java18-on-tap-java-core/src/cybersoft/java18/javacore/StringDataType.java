package cybersoft.java18.javacore;

public class StringDataType {
	public static void main(String[] args) {
		String shortString = null;
		String anotherString = "This is a string";
		String thirdString = new String("This is a string");
		
		if (shortString != null 
				&& shortString.equals("This is a string")) {
			System.out.println("This is a string");
		}
		
		String text = "1" + "2" + "3" + "4";
		
		String betterText = new StringBuilder().append("1")
				.append("2")
				.append("3")
				.append("4")
				.toString();
	}
}
