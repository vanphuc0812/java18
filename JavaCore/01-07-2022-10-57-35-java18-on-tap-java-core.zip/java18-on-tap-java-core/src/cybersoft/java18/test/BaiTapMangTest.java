package cybersoft.java18.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.LinkedList;
import java.util.List;

import org.junit.jupiter.api.Test;

import cybersoft.java18.javacore.BaiTapMang;

public class BaiTapMangTest {
	
	@Test
	void shouldLayDsSoNguyenToTuMangWorkCorrectly() {
		List<Integer> mangInt = List.of(-5, 5, 7, 13 ,21, 24, 25);
		
		List<Integer> mangSoNguyenTo = BaiTapMang.layDsSoNguyenToTuMang(mangInt);
		
		assertEquals(3, mangSoNguyenTo.size());
		assertEquals(5, mangSoNguyenTo.get(0));
		assertEquals(7, mangSoNguyenTo.get(1));
		assertEquals(13, mangSoNguyenTo.get(2));
		
		mangInt = List.of();
		mangSoNguyenTo = BaiTapMang.layDsSoNguyenToTuMang(mangInt);
		
		assertEquals(0, mangSoNguyenTo.size());
		
		mangInt = List.of(4, 6, 8, 12);
		mangSoNguyenTo = BaiTapMang.layDsSoNguyenToTuMang(mangInt);
		
		assertEquals(0, mangSoNguyenTo.size());
	}
	
	@Test
	void shouldOriginalListShouldNotBeModified() {
		List<Integer> mangInt = new LinkedList<>();
		
		mangInt.add(3);
		mangInt.add(5);
		mangInt.add(7);
		
		mangInt.stream().forEach(soN -> {
			soN = 0;
		});
		
		assertEquals(3,  mangInt.get(0));
		assertEquals(5,  mangInt.get(1));
		assertEquals(7,  mangInt.get(2));
	}

}
