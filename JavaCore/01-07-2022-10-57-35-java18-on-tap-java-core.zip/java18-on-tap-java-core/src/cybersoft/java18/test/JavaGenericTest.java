package cybersoft.java18.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import cybersoft.java18.javacore.JavaGeneric;

public class JavaGenericTest {

	@Test
	void shouldWorkCorrectly() {
		// check String type
		JavaGeneric<String> stringType = new JavaGeneric<String>();
		assertEquals(true, stringType.isMatchedType("This is a string", String.class));
		assertEquals(false, stringType.isMatchedType(10, String.class));
		assertEquals(false, stringType.isMatchedType(10.5f, String.class));
		assertEquals(false, stringType.isMatchedType(10.5, String.class));
		// stringType.isMatchedType(10.5, Double.class);
		// boiler plate
		// backbone
		
		// check Integer
		JavaGeneric<Integer> intType = new JavaGeneric<Integer>();
		assertEquals(true, intType.isMatchedType(115, Integer.class));
		assertEquals(false, intType.isMatchedType(10.5, Integer.class));
	}
}
