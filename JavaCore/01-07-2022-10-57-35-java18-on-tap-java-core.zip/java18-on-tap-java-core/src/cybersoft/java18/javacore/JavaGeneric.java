package cybersoft.java18.javacore;

public class JavaGeneric <T> {
	// data type safe
	// []
	public static void main(String[] args) {
		printToConsole("Tuấn Phan");
		printToConsole(new Integer(100));
	}
	
	public static boolean isString(Object obj) {
		if (obj instanceof String)
			return true;
		return false;
	}
	
	public static <T> void printToConsole(T obj) {
		System.out.println("Data: " + obj.toString());
	}
	
	public boolean isMatchedType(Object obj, Class<T> clazz) {
		try {
			clazz.cast(obj);
		} catch(Exception ex) {
			return false;
		}
		return true;
	}
}
