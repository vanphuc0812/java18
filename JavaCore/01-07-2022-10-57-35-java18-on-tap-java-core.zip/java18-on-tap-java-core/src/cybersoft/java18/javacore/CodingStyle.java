package cybersoft.java18.javacore;

public class CodingStyle {
	
	/***
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Ngay hàng thẳng lối.");
		if ("Hôm nay trời không mưa".length() > 5) {
			// do something
		}
		
		if ("Trong body của if chỉ có 1 dòng".length() == 1) {
			// không nên bỏ scope
		}
		
		int a = 5;
		if (a > 10)
			System.out.println("A lớn hơn 10");
		
		// inline comment
		if (a == 10 /* comment cho ngầu */) { // comment vầy mới ngầu
			
		}
		
		functionWithDocumentation("Hello");
		
		/**
		 *  CLEAN CODE
		 */
		
		/**
		 *  Đặt tên biến có ý nghĩa!!!
		 *  Ví dụ: int soInt; double tongDuNo;
		 *  Chống chỉ định: int soX = 5; -> x là gì????
		 *  
		 *  Đặt tên hàm có ý nghĩa!!!
		 *  
		 *  Nên tách hàm nếu thấy code quá dài!
		 *  
		 *  Pseudo code
		 */
		
	}
	
	/***
	 * @author Tuấn Phan
	 * @param name -> tên của hàm
	 * @return Hàm này viết cho vui, không return gì trơn
	 */
	public static void functionWithDocumentation (String name) {
		System.out.println("I'm a function.");
	}
}
