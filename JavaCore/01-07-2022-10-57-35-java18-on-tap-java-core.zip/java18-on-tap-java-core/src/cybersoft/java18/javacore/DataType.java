package cybersoft.java18.javacore;

public class DataType {
	/*
	 * Primitive
	 */
	public void primitiveDataType () {
		// number and logic
		
		// số nguyên
		// byte
		// int
		// long
		// char
		
		// số thực
		// float
		// double
		
		// logic
		// boolean
		
		// reference
		// Object: ArrayList, SinhVien, BankAccount
		// String
	}
}
